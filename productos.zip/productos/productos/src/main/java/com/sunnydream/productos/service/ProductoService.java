package com.sunnydream.productos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunnydream.productos.model.Producto;
import com.sunnydream.productos.repository.ProductoRepository;

@Service
public class ProductoService {
    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> listarProductos(){
        return productoRepository.findAll();
    }

    public Optional<Producto> buscarProducto(Long id){
        return productoRepository.findById(id);
    }
    
    public Producto guardar(Producto producto){
        return productoRepository.save(producto);
    }


    public void eliminarProducto(Long id){
        productoRepository.deleteById(id);
    }

    public List<Producto> stockBajo(int cantidad){
        return productoRepository.findByStockLessThan(cantidad);
    }

}
